"""
estudiantes/models.py

Gestión de Estudiantes, Encargados y sus relaciones de parentesco.
Implementa el patrón Subtipo en Estudiante y Encargado con OneToOneField hacia Persona (primary_key=True).
"""
from django.core.validators import MinLengthValidator
from django.db import models
from APPS.core.models import (
    ModeloAuditable,
    Persona,
    DocumentoExpediente,
    TipoDocumentoExpedienteChoices,
    ContactoPersona,
    TipoVinculoContactoChoices,
)
from APPS.core.validadores import validador_codigo_mineduc


class ParentescoChoices(models.TextChoices):
    PADRE   = 'PADRE',   'Padre'
    MADRE   = 'MADRE',   'Madre'
    ABUELO  = 'ABUELO',  'Abuelo/a'
    TIO     = 'TIO',     'Tío/a'
    HERMANO = 'HERMANO', 'Hermano/a'
    TUTOR   = 'TUTOR',   'Encargado Legal'
    OTRO    = 'OTRO',    'Otro'


class EstadoEstudianteChoices(models.TextChoices):
    ACTIVO     = 'ACTIVO',     'Activo'
    RETIRADO   = 'RETIRADO',   'Retirado'
    GRADUADO   = 'GRADUADO',   'Graduado'
    SUSPENDIDO = 'SUSPENDIDO', 'Suspendido'


class Estudiante(ModeloAuditable):
    """
    Subtipo de Persona para representar a los estudiantes inscritos (Normalizado en 4FN).
    La relación persona (OneToOneField) actúa como llave primaria.
    Los hechos multivaluados independientes (documentos de expediente y contactos de padres)
    se almacenan en DocumentoExpediente y ContactoPersona, manteniendo propiedades retrocompatibles.
    """
    _MAPA_DOCUMENTOS = {
        'doc_cert_nacimiento_renap': TipoDocumentoExpedienteChoices.CERT_NACIMIENTO_RENAP,
        'doc_dpi_encargado': TipoDocumentoExpedienteChoices.DPI_ENCARGADO,
        'doc_certificado_grado_anterior': TipoDocumentoExpedienteChoices.CERTIFICADO_GRADO_ANTERIOR,
        'doc_diploma_primaria': TipoDocumentoExpedienteChoices.DIPLOMA_PRIMARIA,
        'doc_codigo_mineduc': TipoDocumentoExpedienteChoices.CODIGO_MINEDUC,
    }

    persona = models.OneToOneField(
        Persona,
        on_delete=models.RESTRICT,
        primary_key=True,
        related_name='estudiante',
        verbose_name='Persona'
    )
    codigo_mineduc = models.CharField(
        max_length=15,
        unique=True,
        validators=[MinLengthValidator(5), validador_codigo_mineduc],
        verbose_name='Código MINEDUC',
        help_text='Código Personal único otorgado por el MINEDUC (SIRE).'
    )
    estado_estudiante = models.CharField(
        max_length=20,
        choices=EstadoEstudianteChoices.choices,
        default=EstadoEstudianteChoices.ACTIVO,
        verbose_name='Estado académico'
    )
    encargado = models.ForeignKey(
        'Encargado',
        on_delete=models.RESTRICT,
        null=True,
        blank=True,
        related_name='estudiantes',
        verbose_name='Padre de Familia o Encargado'
    )
    historial_medico = models.TextField(
        max_length=500,
        blank=True,
        verbose_name='Historial médico',
        help_text='Información médica relevante, alergias, afecciones, etc.'
    )

    class Meta:
        verbose_name = 'Estudiante'
        verbose_name_plural = 'Estudiantes'

    def __str__(self):
        return f"{self.persona.nombre_completo} (MINEDUC: {self.codigo_mineduc})"

    @classmethod
    def obtener_anotaciones_sql(cls) -> dict:
        from django.db.models import Exists, OuterRef, Case, When, Value, BooleanField
        anotaciones = {
            'estado_activo': Case(
                When(estado_estudiante=EstadoEstudianteChoices.ACTIVO, then=Value(True)),
                default=Value(False),
                output_field=BooleanField(),
            ),
        }
        for attr_name, tipo_doc in cls._MAPA_DOCUMENTOS.items():
            anotaciones[attr_name] = Exists(
                DocumentoExpediente.todos.filter(
                    persona_id=OuterRef('persona_id'),
                    tipo_documento=tipo_doc,
                    entregado=True,
                    esta_eliminado=False,
                )
            )
        return anotaciones

    def _obtener_cache_docs(self) -> dict[str, bool]:
        if '_docs_cache' not in self.__dict__:
            self.__dict__['_docs_cache'] = {}
            if self.persona_id:
                entregados = set(
                    DocumentoExpediente.todos.filter(
                        persona_id=self.persona_id,
                        entregado=True,
                        esta_eliminado=False,
                    ).values_list('tipo_documento', flat=True)
                )
                for attr_name, tipo_doc in self._MAPA_DOCUMENTOS.items():
                    self.__dict__['_docs_cache'][attr_name] = (tipo_doc in entregados)
        return self.__dict__['_docs_cache']

    def _obtener_doc(self, attr_name: str) -> bool:
        cache = self._obtener_cache_docs()
        return bool(cache.get(attr_name, False))

    def _asignar_doc(self, attr_name: str, valor: bool) -> None:
        if '_docs_cache' not in self.__dict__:
            self.__dict__['_docs_cache'] = {}
        self.__dict__['_docs_cache'][attr_name] = bool(valor)
        if '_docs_modificados' not in self.__dict__:
            self.__dict__['_docs_modificados'] = set()
        self.__dict__['_docs_modificados'].add(attr_name)

    def _obtener_cache_contactos(self) -> dict[str, dict[str, str]]:
        if '_contactos_cache' not in self.__dict__:
            self.__dict__['_contactos_cache'] = {
                TipoVinculoContactoChoices.PADRE: {'nombre': '', 'telefono': ''},
                TipoVinculoContactoChoices.MADRE: {'nombre': '', 'telefono': ''},
            }
            if self.persona_id:
                for c in ContactoPersona.todos.filter(
                    persona_id=self.persona_id,
                    tipo_vinculo__in=[TipoVinculoContactoChoices.PADRE, TipoVinculoContactoChoices.MADRE],
                    esta_eliminado=False,
                ):
                    self.__dict__['_contactos_cache'][c.tipo_vinculo] = {
                        'nombre': c.nombre_completo or '',
                        'telefono': c.telefono or '',
                    }
        return self.__dict__['_contactos_cache']

    def _asignar_contacto(self, vinculo: str, campo: str, valor: str) -> None:
        cache = self._obtener_cache_contactos()
        cache.setdefault(vinculo, {'nombre': '', 'telefono': ''})[campo] = (valor or '').strip()
        if '_contactos_modificados' not in self.__dict__:
            self.__dict__['_contactos_modificados'] = set()
        self.__dict__['_contactos_modificados'].add(vinculo)

    @property
    def nombre_padre(self) -> str:
        return self._obtener_cache_contactos()[TipoVinculoContactoChoices.PADRE]['nombre']

    @nombre_padre.setter
    def nombre_padre(self, valor: str) -> None:
        self._asignar_contacto(TipoVinculoContactoChoices.PADRE, 'nombre', valor)

    @property
    def telefono_padre(self) -> str:
        return self._obtener_cache_contactos()[TipoVinculoContactoChoices.PADRE]['telefono']

    @telefono_padre.setter
    def telefono_padre(self, valor: str) -> None:
        self._asignar_contacto(TipoVinculoContactoChoices.PADRE, 'telefono', valor)

    @property
    def nombre_madre(self) -> str:
        return self._obtener_cache_contactos()[TipoVinculoContactoChoices.MADRE]['nombre']

    @nombre_madre.setter
    def nombre_madre(self, valor: str) -> None:
        self._asignar_contacto(TipoVinculoContactoChoices.MADRE, 'nombre', valor)

    @property
    def telefono_madre(self) -> str:
        return self._obtener_cache_contactos()[TipoVinculoContactoChoices.MADRE]['telefono']

    @telefono_madre.setter
    def telefono_madre(self, valor: str) -> None:
        self._asignar_contacto(TipoVinculoContactoChoices.MADRE, 'telefono', valor)

    @property
    def doc_cert_nacimiento_renap(self) -> bool:
        return self._obtener_doc('doc_cert_nacimiento_renap')

    @doc_cert_nacimiento_renap.setter
    def doc_cert_nacimiento_renap(self, valor: bool) -> None:
        self._asignar_doc('doc_cert_nacimiento_renap', valor)

    @property
    def doc_dpi_encargado(self) -> bool:
        return self._obtener_doc('doc_dpi_encargado')

    @doc_dpi_encargado.setter
    def doc_dpi_encargado(self, valor: bool) -> None:
        self._asignar_doc('doc_dpi_encargado', valor)

    @property
    def doc_certificado_grado_anterior(self) -> bool:
        return self._obtener_doc('doc_certificado_grado_anterior')

    @doc_certificado_grado_anterior.setter
    def doc_certificado_grado_anterior(self, valor: bool) -> None:
        self._asignar_doc('doc_certificado_grado_anterior', valor)

    @property
    def doc_diploma_primaria(self) -> bool:
        return self._obtener_doc('doc_diploma_primaria')

    @doc_diploma_primaria.setter
    def doc_diploma_primaria(self, valor: bool) -> None:
        self._asignar_doc('doc_diploma_primaria', valor)

    @property
    def doc_codigo_mineduc(self) -> bool:
        return self._obtener_doc('doc_codigo_mineduc')

    @doc_codigo_mineduc.setter
    def doc_codigo_mineduc(self, valor: bool) -> None:
        self._asignar_doc('doc_codigo_mineduc', valor)

    @property
    def estado_activo(self) -> bool:
        return self.estado_estudiante == EstadoEstudianteChoices.ACTIVO

    @estado_activo.setter
    def estado_activo(self, valor: bool) -> None:
        if not valor and self.estado_estudiante == EstadoEstudianteChoices.ACTIVO:
            self.estado_estudiante = EstadoEstudianteChoices.RETIRADO
        elif valor and not self.estado_estudiante:
            self.estado_estudiante = EstadoEstudianteChoices.ACTIVO

    def refresh_from_db(self, using=None, fields=None, from_queryset=None):
        self.__dict__.pop('_docs_cache', None)
        self.__dict__.pop('_docs_modificados', None)
        self.__dict__.pop('_contactos_cache', None)
        self.__dict__.pop('_contactos_modificados', None)
        return super().refresh_from_db(using=using, fields=fields, from_queryset=from_queryset)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not self.persona_id:
            return

        # persistir documentos de expediente modificados
        docs_mod = self.__dict__.get('_docs_modificados', set())
        docs_cache = self.__dict__.get('_docs_cache', {})
        for attr_name in list(docs_mod):
            tipo_doc = self._MAPA_DOCUMENTOS.get(attr_name)
            if not tipo_doc:
                continue
            entregado = bool(docs_cache.get(attr_name, False))
            DocumentoExpediente.todos.update_or_create(
                persona_id=self.persona_id,
                tipo_documento=tipo_doc,
                defaults={'entregado': entregado, 'esta_eliminado': False},
            )
        self.__dict__.pop('_docs_modificados', None)

        # persistir contactos familiares modificados
        contactos_mod = self.__dict__.get('_contactos_modificados', set())
        contactos_cache = self.__dict__.get('_contactos_cache', {})
        for vinculo in list(contactos_mod):
            datos = contactos_cache.get(vinculo, {})
            nombre = (datos.get('nombre') or '').strip()
            telefono = (datos.get('telefono') or '').strip()
            if nombre or telefono:
                ContactoPersona.todos.update_or_create(
                    persona_id=self.persona_id,
                    tipo_vinculo=vinculo,
                    defaults={
                        'nombre_completo': nombre,
                        'telefono': telefono,
                        'esta_eliminado': False,
                    },
                )
            else:
                ContactoPersona.todos.filter(
                    persona_id=self.persona_id,
                    tipo_vinculo=vinculo,
                ).update(esta_eliminado=True)
        self.__dict__.pop('_contactos_modificados', None)

        # sincronizar relacion con encargado principal
        if self.encargado_id:
            EstudianteEncargado.todos.update_or_create(
                estudiante=self,
                encargado_id=self.encargado_id,
                defaults={'es_contacto_principal': True, 'esta_eliminado': False},
                create_defaults={'parentesco': ParentescoChoices.TUTOR, 'es_contacto_principal': True},
            )

    @property
    def expediente_completo(self):
        """Indica si entregó los 5 documentos obligatorios del MINEDUC."""
        return all([
            self.doc_cert_nacimiento_renap,
            self.doc_dpi_encargado,
            self.doc_certificado_grado_anterior,
            self.doc_diploma_primaria,
            self.doc_codigo_mineduc
        ])

    @property
    def documentos_entregados_count(self):
        """Retorna el número de documentos obligatorios entregados (0 a 5)."""
        docs = [
            self.doc_cert_nacimiento_renap,
            self.doc_dpi_encargado,
            self.doc_certificado_grado_anterior,
            self.doc_diploma_primaria,
            self.doc_codigo_mineduc
        ]
        return sum(1 for d in docs if d)

    @property
    def porcentaje_expediente(self):
        """Retorna el porcentaje de papelería física completada (0 a 100)."""
        return int((self.documentos_entregados_count / 5) * 100)

    @property
    def cuenta_inscripcion_actual(self):
        """Retorna la cuenta por cobrar correspondiente a la inscripción del estudiante."""
        from django.db.models import Q
        return self.cuentas_por_cobrar.filter(
            esta_eliminado=False
        ).filter(
            Q(concepto__aplica_al_inscribir_seccion=True) |
            Q(concepto__categoria_concepto='MATRICULA') |
            Q(concepto__nombre__icontains='inscripci')
        ).order_by('-ciclo_escolar__anio', '-creado_en').first()

    @property
    def saldo_total_pendiente(self):
        """Suma de saldo pendiente en todas las obligaciones financieras activas del estudiante."""
        return sum((c.saldo_pendiente for c in self.cuentas_por_cobrar.filter(esta_eliminado=False)), 0)

    @property
    def solvencia_inscripcion_estado(self):
        """
        Evalúa el estado de solvencia específico para la cuota de inscripción escolar:
        Retorna 'SOLVENTE', 'PENDIENTE' o 'SIN_COBRO'.
        """
        c_insc = self.cuenta_inscripcion_actual
        if not c_insc:
            return 'SIN_COBRO'
        if c_insc.saldo_pendiente == 0:
            return 'SOLVENTE'
        return 'PENDIENTE'

    @property
    def semaforo_disciplina(self):
        """
        Calcula el estado del semáforo disciplinario escolar (Acuerdo Ministerial 01-2011):
        - VERDE: 0 faltas registradas.
        - AMARILLO: 1 o 2 faltas leves.
        - ROJO: 1 o más faltas GRAVES o MUY GRAVES, o más de 2 faltas leves acumuladas.
        """
        incidentes = self.incidentes_conductuales.filter(esta_eliminado=False)
        total = incidentes.count()
        if total == 0:
            return {
                'estado': 'VERDE',
                'label': 'Excelente Disciplina',
                'class': 'bg-emerald-50 text-emerald-700 border-emerald-300',
                'icono': 'shield-check',
                'faltas_leves': 0,
                'faltas_graves': 0,
                'total': 0,
            }
        
        graves = incidentes.filter(tipo_falta__in=['GRAVE', 'MUY_GRAVE']).count()
        leves = incidentes.filter(tipo_falta='LEVE').count()
        
        if graves > 0 or leves >= 3:
            return {
                'estado': 'ROJO',
                'label': 'Alerta Disciplinaria',
                'class': 'bg-rose-50 text-rose-700 border-rose-300',
                'icono': 'alert-triangle',
                'faltas_leves': leves,
                'faltas_graves': graves,
                'total': total,
            }
        else:
            return {
                'estado': 'AMARILLO',
                'label': 'En Observación',
                'class': 'bg-amber-50 text-amber-700 border-amber-300',
                'icono': 'alert-circle',
                'faltas_leves': leves,
                'faltas_graves': 0,
                'total': total,
            }

    @property
    def incidentes_disciplinarios(self):
        """Retorna el queryset de incidentes disciplinarios del estudiante."""
        return self.incidentes_conductuales

    @property
    def semaforo_conducta(self):
        """Alias retrocompatible hacia semaforo_disciplina."""
        return self.semaforo_disciplina




class Encargado(ModeloAuditable):
    """
    Subtipo de Persona para representar a los padres de familia o encargados.
    La relación persona (OneToOneField) actúa como llave primaria.
    """
    persona = models.OneToOneField(
        Persona,
        on_delete=models.RESTRICT,
        primary_key=True,
        related_name='encargado',
        verbose_name='Persona'
    )
    lugar_de_trabajo = models.CharField(
        max_length=150,
        blank=True,
        validators=[MinLengthValidator(2)],
        verbose_name='Lugar de trabajo'
    )

    class Meta:
        verbose_name = 'Encargado'
        verbose_name_plural = 'Encargados'

    def __str__(self):
        return f"{self.persona.nombre_completo} (Lugar de trabajo: {self.lugar_de_trabajo or 'N/A'})"


class EstudianteEncargado(ModeloAuditable):
    """
    Tabla pivote N:M entre Estudiantes y Encargados especificando parentesco y contacto principal.
    """
    estudiante = models.ForeignKey(
        Estudiante,
        on_delete=models.RESTRICT,
        related_name='encargados_rel',
        verbose_name='Estudiante'
    )
    encargado = models.ForeignKey(
        Encargado,
        on_delete=models.RESTRICT,
        related_name='estudiantes_rel',
        verbose_name='Encargado'
    )
    parentesco = models.CharField(
        max_length=20,
        choices=ParentescoChoices.choices,
        verbose_name='Parentesco'
    )
    es_contacto_principal = models.BooleanField(
        default=False,
        verbose_name='¿Es contacto principal?'
    )

    class Meta:
        verbose_name = 'Relación Estudiante-Encargado'
        verbose_name_plural = 'Relaciones Estudiante-Encargado'
        unique_together = [['estudiante', 'encargado']]

    def __str__(self):
        return f"{self.estudiante.persona.nombre_completo} - {self.encargado.persona.nombre_completo} ({self.get_parentesco_display()})"

