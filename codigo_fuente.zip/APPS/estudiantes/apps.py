from django.apps import AppConfig


class EstudiantesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'APPS.estudiantes'
    verbose_name = 'Gestión de Estudiantes'
