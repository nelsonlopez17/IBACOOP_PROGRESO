"""
core/forms.py

Mixin reutilizable para la aplicación de estilos de Tailwind CSS v4 y DaisyUI,
propagación automática de restricciones HTML5 (maxlength, minlength, min, max)
y Formulario base para el Supertipo Persona (APPS.core.models).
"""
from datetime import date
from django import forms
from APPS.core.models import Persona
from APPS.core.validadores import (
    limpiar_cui_guatemala,
    limpiar_telefono_guatemala,
    limpiar_texto_longitud,
)


class TailwindFormMixin:
    """
    Clase auxiliar para aplicar estilos corporativos Tailwind a los campos del formulario
    y sincronizar automáticamente atributos HTML5 de longitud y rango con el backend y la BD.
    """

    def _aplicar_estilos_tailwind(self):
        model_meta = getattr(getattr(self, '_meta', None), 'model', None)
        for name, field in self.fields.items():
            widget_type = field.widget.__class__.__name__

            # propagacion automatica de longitudes y limites numericos hacia el formulario html
            if getattr(field, 'max_length', None) and 'maxlength' not in field.widget.attrs:
                field.widget.attrs['maxlength'] = str(field.max_length)
            elif model_meta is not None and 'maxlength' not in field.widget.attrs:
                try:
                    model_field = model_meta._meta.get_field(name)
                    if getattr(model_field, 'max_length', None):
                        field.widget.attrs['maxlength'] = str(model_field.max_length)
                except Exception:
                    pass

            if getattr(field, 'min_length', None) and 'minlength' not in field.widget.attrs:
                field.widget.attrs['minlength'] = str(field.min_length)
            elif model_meta is not None and 'minlength' not in field.widget.attrs:
                try:
                    model_field = model_meta._meta.get_field(name)
                    for val in getattr(model_field, 'validators', []):
                        if val.__class__.__name__ == 'MinLengthValidator' and getattr(val, 'limit_value', None):
                            field.widget.attrs['minlength'] = str(val.limit_value)
                            break
                except Exception:
                    pass

            if getattr(field, 'min_value', None) is not None and 'min' not in field.widget.attrs:
                field.widget.attrs['min'] = str(field.min_value)
            if getattr(field, 'max_value', None) is not None and 'max' not in field.widget.attrs:
                field.widget.attrs['max'] = str(field.max_value)

            if widget_type == 'CheckboxInput':
                field.widget.attrs['class'] = (
                    'h-5 w-5 rounded border-slate-300 bg-white text-[#1E6532] '
                    'focus:ring-[#1E6532] focus:ring-offset-white cursor-pointer transition'
                )
            elif widget_type == 'CheckboxSelectMultiple':
                pass
            elif widget_type in ['Select', 'SelectMultiple']:
                field.widget.attrs['class'] = (
                    'w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg '
                    'text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E6532] '
                    'focus:border-[#1E6532] transition-colors shadow-sm text-sm'
                )
            elif widget_type == 'DateInput':
                field.widget.attrs.update({
                    'type': 'date',
                    'class': (
                        'w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg '
                        'text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#1E6532] '
                        'focus:border-[#1E6532] transition-colors shadow-sm text-sm'
                    )
                })
            else:
                field.widget.attrs['class'] = (
                    'w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg '
                    'text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 '
                    'focus:ring-[#1E6532] focus:border-[#1E6532] transition-colors shadow-sm text-sm'
                )

    def _marcar_widget_con_error(self, field_name):
        if not field_name or field_name not in self.fields:
            return
        field = self.fields[field_name]
        clases_actuales = field.widget.attrs.get('class', '')
        clases_limpias = (
            clases_actuales
            .replace('border-slate-300', 'border-rose-500')
            .replace('border-slate-200', 'border-rose-500')
            .replace('bg-white', 'bg-rose-50/30')
            .replace('focus:ring-[#1E6532]', 'focus:ring-rose-500')
            .replace('focus:border-[#1E6532]', 'focus:border-rose-500')
        )
        if 'border-rose-500' not in clases_limpias:
            clases_limpias = f"{clases_limpias} border-rose-500 focus:ring-rose-500 focus:border-rose-500".strip()
        field.widget.attrs['class'] = clases_limpias
        field.widget.attrs['aria-invalid'] = 'true'

    def full_clean(self):
        super().full_clean()
        if hasattr(self, '_errors') and self._errors:
            for field_name in self._errors:
                self._marcar_widget_con_error(field_name)

    def add_error(self, field, error):
        super().add_error(field, error)
        if field:
            self._marcar_widget_con_error(field)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._aplicar_estilos_tailwind()


class PersonaForm(TailwindFormMixin, forms.ModelForm):
    """Formulario para la captura de información personal (Supertipo Persona)."""

    class Meta:
        model = Persona
        fields = [
            'cui',
            'nombres',
            'apellidos',
            'fecha_nacimiento',
            'genero',
            'direccion',
            'telefono_principal',
            'telefono_secundario',
            'correo',
        ]
        labels = {
            'cui': 'CUI / DPI (13 dígitos)',
            'nombres': 'Nombres',
            'apellidos': 'Apellidos',
            'fecha_nacimiento': 'Fecha de Nacimiento',
            'genero': 'Género',
            'direccion': 'Dirección Domiciliar',
            'telefono_principal': 'Teléfono Principal (8 dígitos)',
            'telefono_secundario': 'Teléfono Secundario (8 dígitos)',
            'correo': 'Correo Electrónico de Contacto',
        }
        widgets = {
            'cui': forms.TextInput(attrs={
                'minlength': '13',
                'maxlength': '13',
                'pattern': r'\d{13}',
                'inputmode': 'numeric',
                'oninput': "this.value = this.value.replace(/[^0-9]/g, '').slice(0, 13)",
                'placeholder': 'Ej. 2580123450101',
                'title': 'Ingrese los 13 dígitos numéricos del CUI / DPI (RENAP).',
            }),
            'nombres': forms.TextInput(attrs={
                'minlength': '2',
                'maxlength': '100',
                'placeholder': 'Nombres completos según RENAP',
            }),
            'apellidos': forms.TextInput(attrs={
                'minlength': '2',
                'maxlength': '100',
                'placeholder': 'Apellidos completos según RENAP',
            }),
            'fecha_nacimiento': forms.DateInput(attrs={'type': 'date'}),
            'direccion': forms.Textarea(attrs={
                'rows': 2,
                'maxlength': '300',
                'placeholder': 'Aldea, caserío, barrio o zona, municipio y departamento',
            }),
            'telefono_principal': forms.TextInput(attrs={
                'minlength': '8',
                'maxlength': '8',
                'pattern': r'\d{8}',
                'inputmode': 'numeric',
                'oninput': "this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8)",
                'placeholder': 'Ej. 55551234',
                'title': 'Ingrese un número telefónico de Guatemala de exactamente 8 dígitos numéricos.',
            }),
            'telefono_secundario': forms.TextInput(attrs={
                'minlength': '8',
                'maxlength': '8',
                'pattern': r'\d{8}',
                'inputmode': 'numeric',
                'oninput': "this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8)",
                'placeholder': 'Ej. 44445678 (Opcional)',
                'title': 'Ingrese un número telefónico de Guatemala de exactamente 8 dígitos numéricos.',
            }),
            'correo': forms.EmailInput(attrs={
                'maxlength': '254',
                'placeholder': 'ejemplo@correo.com',
            }),
        }

    def clean_cui(self):
        cui = self.cleaned_data.get('cui')
        if cui:
            return limpiar_cui_guatemala(cui)
        return cui

    def clean_nombres(self):
        nombres = self.cleaned_data.get('nombres')
        return limpiar_texto_longitud(
            nombres,
            nombre_campo='Los nombres',
            min_length=2,
            max_length=100,
            obligatorio=True,
            evitar_solo_numeros=True,
        )

    def clean_apellidos(self):
        apellidos = self.cleaned_data.get('apellidos')
        return limpiar_texto_longitud(
            apellidos,
            nombre_campo='Los apellidos',
            min_length=2,
            max_length=100,
            obligatorio=True,
            evitar_solo_numeros=True,
        )

    def clean_direccion(self):
        direccion = self.cleaned_data.get('direccion')
        if direccion:
            return limpiar_texto_longitud(
                direccion,
                nombre_campo='La dirección domiciliar',
                min_length=3,
                max_length=300,
                obligatorio=False,
            )
        return ''

    def clean_correo(self):
        correo = self.cleaned_data.get('correo')
        if correo:
            correo = correo.strip().lower()
            if len(correo) > 254:
                raise forms.ValidationError('El correo electrónico no puede exceder los 254 caracteres.')
            qs = Persona.objects.filter(correo__iexact=correo, esta_eliminado=False)
            if self.instance and self.instance.pk:
                qs = qs.exclude(pk=self.instance.pk)
            if qs.exists():
                raise forms.ValidationError('Este correo electrónico ya está registrado en el sistema para otra persona.')
        return correo

    def clean_fecha_nacimiento(self):
        fecha = self.cleaned_data.get('fecha_nacimiento')
        if fecha:
            if fecha > date.today():
                raise forms.ValidationError('La fecha de nacimiento no puede ser una fecha futura.')
            if fecha.year < 1900:
                raise forms.ValidationError('Ingrese un año de nacimiento válido.')
        return fecha

    def clean_telefono_principal(self):
        tel = self.cleaned_data.get('telefono_principal')
        if tel:
            return limpiar_telefono_guatemala(tel)
        return tel

    def clean_telefono_secundario(self):
        tel = self.cleaned_data.get('telefono_secundario')
        if tel:
            return limpiar_telefono_guatemala(tel)
        return tel
