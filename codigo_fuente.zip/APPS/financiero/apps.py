from django.apps import AppConfig


class FinancieroConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'APPS.financiero'
    verbose_name = 'Gestión Financiera'
