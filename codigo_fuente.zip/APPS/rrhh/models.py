"""
rrhh/models.py

Recursos Humanos y Planillas de Sueldos del Instituto El Progreso.
Implementa el subtipo Personal (Persona FK primary_key=True), Puesto, AsistenciaPersonal y Planilla.
"""
from decimal import Decimal
from django.core.validators import MinValueValidator, MinLengthValidator
from django.db import models
from simple_history.models import HistoricalRecords
from APPS.core.models import (
    ModeloAuditable,
    Persona,
    DocumentoExpediente,
    TipoDocumentoExpedienteChoices,
    ContactoPersona,
    TipoVinculoContactoChoices,
)
from APPS.core.validadores import validador_nit_sat



class EstadoLaboralChoices(models.TextChoices):
    ACTIVO     = 'ACTIVO',     'Activo'
    BAJA       = 'BAJA',       'Baja temporal'
    RETIRADO   = 'RETIRADO',   'Retirado'
    SUSPENDIDO = 'SUSPENDIDO', 'Suspendido'


class EstadoAsistenciaChoices(models.TextChoices):
    PRESENTE   = 'PRESENTE',   'Presente'
    AUSENTE    = 'AUSENTE',    'Ausente'
    TARDANZA   = 'TARDANZA',   'Tardanza'
    PERMISO    = 'PERMISO',    'Con permiso'
    VACACIONES = 'VACACIONES', 'En vacaciones'


class MesChoices(models.IntegerChoices):
    ENERO      = 1,  'Enero'
    FEBRERO    = 2,  'Febrero'
    MARZO      = 3,  'Marzo'
    ABRIL      = 4,  'Abril'
    MAYO       = 5,  'Mayo'
    JUNIO      = 6,  'Junio'
    JULIO      = 7,  'Julio'
    AGOSTO     = 8,  'Agosto'
    SEPTIEMBRE = 9,  'Septiembre'
    OCTUBRE    = 10, 'Octubre'
    NOVIEMBRE  = 11, 'Noviembre'
    DICIEMBRE  = 12, 'Diciembre'


class Puesto(ModeloAuditable):
    """Representa un cargo o puesto laboral en la institución."""
    nombre_puesto = models.CharField(
        max_length=100,
        unique=True,
        validators=[MinLengthValidator(3)],
        verbose_name='Nombre del puesto'
    )
    descripcion = models.TextField(
        max_length=300,
        blank=True,
        verbose_name='Descripción'
    )

    class Meta:
        verbose_name = 'Puesto'
        verbose_name_plural = 'Puestos'
        ordering = ['nombre_puesto']

    def __str__(self):
        return self.nombre_puesto


class Personal(ModeloAuditable):
    """
    Subtipo de Persona para colaboradores (docentes, administrativos, conserjes) normalizado en 4FN.
    La relación persona (OneToOneField) actúa como llave primaria.
    Los hechos multivaluados independientes (documentos de expediente y contacto de emergencia)
    se almacenan en DocumentoExpediente y ContactoPersona manteniendo propiedades retrocompatibles.
    """
    _MAPA_DOCUMENTOS = {
        'doc_dpi_personal': TipoDocumentoExpedienteChoices.DPI_PERSONAL,
        'doc_nit_sat': TipoDocumentoExpedienteChoices.NIT_SAT,
        'doc_titulo_academico': TipoDocumentoExpedienteChoices.TITULO_ACADEMICO,
        'doc_colegiado_activo': TipoDocumentoExpedienteChoices.COLEGIADO_ACTIVO,
        'doc_antecedentes_penales': TipoDocumentoExpedienteChoices.ANTECEDENTES_PENALES,
        'doc_antecedentes_policiales': TipoDocumentoExpedienteChoices.ANTECEDENTES_POLICIALES,
        'doc_contrato_fisico': TipoDocumentoExpedienteChoices.CONTRATO_FISICO,
        'doc_tarjeta_salud': TipoDocumentoExpedienteChoices.TARJETA_SALUD,
    }

    persona = models.OneToOneField(
        Persona,
        on_delete=models.RESTRICT,
        primary_key=True,
        related_name='personal',
        verbose_name='Persona'
    )
    puesto = models.ForeignKey(
        Puesto,
        on_delete=models.RESTRICT,
        related_name='empleados',
        verbose_name='Puesto'
    )
    nit = models.CharField(
        max_length=15,
        blank=True,
        validators=[validador_nit_sat],
        verbose_name='NIT'
    )
    fecha_contratacion = models.DateField(
        verbose_name='Fecha de contratación'
    )
    estado_laboral = models.CharField(
        max_length=20,
        choices=EstadoLaboralChoices.choices,
        default=EstadoLaboralChoices.ACTIVO,
        verbose_name='Estado laboral'
    )
    salario_base_asignado = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))],
        verbose_name='Salario base asignado (Q)'
    )

    # ubicacion del contrato en archivo de secretaria
    numero_contrato_fisico = models.CharField(
        max_length=50,
        blank=True,
        verbose_name='No. Contrato Físico',
        help_text='Número o correlativo del contrato laboral firmado en físico.'
    )
    ubicacion_expediente_fisico = models.CharField(
        max_length=100,
        blank=True,
        verbose_name='Ubicación Físico (Archivador/Carpeta)',
        help_text='Ej. Archivador B-1, Carpeta 15 (Secretaría).'
    )

    class Meta:
        verbose_name = 'Personal'
        verbose_name_plural = 'Personal'
        ordering = ['persona__apellidos', 'persona__nombres']

    def __str__(self):
        return f"{self.persona.nombre_completo} - {self.puesto.nombre_puesto}"

    @classmethod
    def obtener_anotaciones_sql(cls) -> dict:
        from django.db.models import Exists, OuterRef
        anotaciones = {}
        for attr_name, tipo_doc in cls._MAPA_DOCUMENTOS.items():
            anotaciones[attr_name] = Exists(
                DocumentoExpediente.todos.filter(
                    persona_id=OuterRef('persona_id'),
                    tipo_documento=tipo_doc,
                    entregado=True,
                    esta_eliminado=False,
                )
            )
        return anotaciones

    def _obtener_cache_docs(self) -> dict[str, bool]:
        if '_docs_cache' not in self.__dict__:
            self.__dict__['_docs_cache'] = {}
            if self.persona_id:
                entregados = set(
                    DocumentoExpediente.todos.filter(
                        persona_id=self.persona_id,
                        entregado=True,
                        esta_eliminado=False,
                    ).values_list('tipo_documento', flat=True)
                )
                for attr_name, tipo_doc in self._MAPA_DOCUMENTOS.items():
                    self.__dict__['_docs_cache'][attr_name] = (tipo_doc in entregados)
        return self.__dict__['_docs_cache']

    def _obtener_doc(self, attr_name: str) -> bool:
        return bool(self._obtener_cache_docs().get(attr_name, False))

    def _asignar_doc(self, attr_name: str, valor: bool) -> None:
        if '_docs_cache' not in self.__dict__:
            self.__dict__['_docs_cache'] = {}
        self.__dict__['_docs_cache'][attr_name] = bool(valor)
        if '_docs_modificados' not in self.__dict__:
            self.__dict__['_docs_modificados'] = set()
        self.__dict__['_docs_modificados'].add(attr_name)

    def _obtener_cache_emergencia(self) -> dict[str, str]:
        if '_emergencia_cache' not in self.__dict__:
            self.__dict__['_emergencia_cache'] = {'nombre': '', 'telefono': ''}
            if self.persona_id:
                contacto = ContactoPersona.todos.filter(
                    persona_id=self.persona_id,
                    tipo_vinculo=TipoVinculoContactoChoices.EMERGENCIA,
                    esta_eliminado=False,
                ).first()
                if contacto:
                    self.__dict__['_emergencia_cache'] = {
                        'nombre': contacto.nombre_completo or '',
                        'telefono': contacto.telefono or '',
                    }
        return self.__dict__['_emergencia_cache']

    @property
    def contacto_emergencia_nombre(self) -> str:
        return self._obtener_cache_emergencia()['nombre']

    @contacto_emergencia_nombre.setter
    def contacto_emergencia_nombre(self, valor: str) -> None:
        self._obtener_cache_emergencia()['nombre'] = (valor or '').strip()
        self.__dict__['_emergencia_modificado'] = True

    @property
    def contacto_emergencia_telefono(self) -> str:
        return self._obtener_cache_emergencia()['telefono']

    @contacto_emergencia_telefono.setter
    def contacto_emergencia_telefono(self, valor: str) -> None:
        self._obtener_cache_emergencia()['telefono'] = (valor or '').strip()
        self.__dict__['_emergencia_modificado'] = True

    @property
    def doc_dpi_personal(self) -> bool:
        return self._obtener_doc('doc_dpi_personal')

    @doc_dpi_personal.setter
    def doc_dpi_personal(self, valor: bool) -> None:
        self._asignar_doc('doc_dpi_personal', valor)

    @property
    def doc_nit_sat(self) -> bool:
        return self._obtener_doc('doc_nit_sat')

    @doc_nit_sat.setter
    def doc_nit_sat(self, valor: bool) -> None:
        self._asignar_doc('doc_nit_sat', valor)

    @property
    def doc_titulo_academico(self) -> bool:
        return self._obtener_doc('doc_titulo_academico')

    @doc_titulo_academico.setter
    def doc_titulo_academico(self, valor: bool) -> None:
        self._asignar_doc('doc_titulo_academico', valor)

    @property
    def doc_colegiado_activo(self) -> bool:
        return self._obtener_doc('doc_colegiado_activo')

    @doc_colegiado_activo.setter
    def doc_colegiado_activo(self, valor: bool) -> None:
        self._asignar_doc('doc_colegiado_activo', valor)

    @property
    def doc_antecedentes_penales(self) -> bool:
        return self._obtener_doc('doc_antecedentes_penales')

    @doc_antecedentes_penales.setter
    def doc_antecedentes_penales(self, valor: bool) -> None:
        self._asignar_doc('doc_antecedentes_penales', valor)

    @property
    def doc_antecedentes_policiales(self) -> bool:
        return self._obtener_doc('doc_antecedentes_policiales')

    @doc_antecedentes_policiales.setter
    def doc_antecedentes_policiales(self, valor: bool) -> None:
        self._asignar_doc('doc_antecedentes_policiales', valor)

    @property
    def doc_contrato_fisico(self) -> bool:
        return self._obtener_doc('doc_contrato_fisico')

    @doc_contrato_fisico.setter
    def doc_contrato_fisico(self, valor: bool) -> None:
        self._asignar_doc('doc_contrato_fisico', valor)

    @property
    def doc_tarjeta_salud(self) -> bool:
        return self._obtener_doc('doc_tarjeta_salud')

    @doc_tarjeta_salud.setter
    def doc_tarjeta_salud(self, valor: bool) -> None:
        self._asignar_doc('doc_tarjeta_salud', valor)

    def refresh_from_db(self, using=None, fields=None, from_queryset=None):
        self.__dict__.pop('_docs_cache', None)
        self.__dict__.pop('_docs_modificados', None)
        self.__dict__.pop('_emergencia_cache', None)
        self.__dict__.pop('_emergencia_modificado', None)
        return super().refresh_from_db(using=using, fields=fields, from_queryset=from_queryset)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if not self.persona_id:
            return

        # persistir documentos de expediente modificados
        docs_mod = self.__dict__.get('_docs_modificados', set())
        docs_cache = self.__dict__.get('_docs_cache', {})
        for attr_name in list(docs_mod):
            tipo_doc = self._MAPA_DOCUMENTOS.get(attr_name)
            if not tipo_doc:
                continue
            entregado = bool(docs_cache.get(attr_name, False))
            DocumentoExpediente.todos.update_or_create(
                persona_id=self.persona_id,
                tipo_documento=tipo_doc,
                defaults={'entregado': entregado, 'esta_eliminado': False},
            )
        self.__dict__.pop('_docs_modificados', None)

        # persistir contacto de emergencia modificado
        if self.__dict__.get('_emergencia_modificado'):
            emerg = self.__dict__.get('_emergencia_cache', {})
            nombre = (emerg.get('nombre') or '').strip()
            telefono = (emerg.get('telefono') or '').strip()
            if nombre or telefono:
                ContactoPersona.todos.update_or_create(
                    persona_id=self.persona_id,
                    tipo_vinculo=TipoVinculoContactoChoices.EMERGENCIA,
                    defaults={
                        'nombre_completo': nombre,
                        'telefono': telefono,
                        'esta_eliminado': False,
                    },
                )
            else:
                ContactoPersona.todos.filter(
                    persona_id=self.persona_id,
                    tipo_vinculo=TipoVinculoContactoChoices.EMERGENCIA,
                ).update(esta_eliminado=True)
            self.__dict__.pop('_emergencia_modificado', None)

    @property
    def expediente_completo(self):
        """Indica si se entregaron los documentos obligatorios principales."""
        return all([
            self.doc_dpi_personal,
            self.doc_nit_sat,
            self.doc_titulo_academico,
            self.doc_antecedentes_penales,
            self.doc_antecedentes_policiales,
            self.doc_contrato_fisico
        ])

    @property
    def documentos_entregados_count(self):
        """Retorna la cantidad de documentos entregados de la lista (0 a 8)."""
        docs = [
            self.doc_dpi_personal,
            self.doc_nit_sat,
            self.doc_titulo_academico,
            self.doc_colegiado_activo,
            self.doc_antecedentes_penales,
            self.doc_antecedentes_policiales,
            self.doc_contrato_fisico,
            self.doc_tarjeta_salud
        ]
        return sum(1 for d in docs if d)

    @property
    def porcentaje_expediente(self):
        """Retorna el porcentaje de papelería física completada (0 a 100)."""
        return int((self.documentos_entregados_count / 8) * 100)



class AsistenciaPersonal(ModeloAuditable):
    """Registro diario de asistencia del personal."""
    personal = models.ForeignKey(
        Personal,
        on_delete=models.RESTRICT,
        related_name='asistencias',
        verbose_name='Personal'
    )
    fecha = models.DateField(
        verbose_name='Fecha'
    )
    hora_entrada = models.TimeField(
        null=True,
        blank=True,
        verbose_name='Hora de entrada'
    )
    hora_salida = models.TimeField(
        null=True,
        blank=True,
        verbose_name='Hora de salida'
    )
    estado_asistencia = models.CharField(
        max_length=20,
        choices=EstadoAsistenciaChoices.choices,
        default=EstadoAsistenciaChoices.PRESENTE,
        verbose_name='Estado de asistencia'
    )
    observaciones = models.TextField(
        max_length=300,
        blank=True,
        verbose_name='Observaciones'
    )

    class Meta:
        verbose_name = 'Asistencia de Personal'
        verbose_name_plural = 'Asistencias de Personal'
        unique_together = [['personal', 'fecha']]
        ordering = ['-fecha', 'personal']

    def __str__(self):
        return f"{self.personal.persona.nombre_completo} - {self.fecha} ({self.get_estado_asistencia_display()})"


class Planilla(ModeloAuditable):
    """
    Registro de pago de planilla mensual de personal (Normalizado en 3FN/4FN).
    El atributo derivado `total_pagar` se calcula dinámicamente a partir de
    personal.salario_base_asignado + bonificaciones - descuentos sin redundancia física.
    """
    personal = models.ForeignKey(
        Personal,
        on_delete=models.RESTRICT,
        related_name='planillas',
        verbose_name='Personal'
    )
    ciclo_escolar = models.ForeignKey(
        'academico.CicloEscolar',
        on_delete=models.RESTRICT,
        null=True,
        blank=True,
        related_name='planillas',
        verbose_name='Ciclo Escolar'
    )
    mes_pagado = models.IntegerField(
        choices=MesChoices.choices,
        verbose_name='Mes pagado'
    )
    bonificaciones = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name='Bonificaciones (Q)'
    )
    descuentos = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        validators=[MinValueValidator(Decimal('0.00'))],
        verbose_name='Descuentos (Q)'
    )
    comprobante_pdf = models.FileField(
        upload_to='planillas/%Y/%m/',
        null=True,
        blank=True,
        verbose_name='Comprobante PDF'
    )
    fecha_pago = models.DateField(
        null=True,
        blank=True,
        verbose_name='Fecha de pago'
    )
    pagado = models.BooleanField(
        default=False,
        verbose_name='¿Pagado?'
    )
    history = HistoricalRecords(
        verbose_name='Auditoría de Planilla'
    )

    class Meta:
        verbose_name = 'Planilla'
        verbose_name_plural = 'Planillas'
        unique_together = [['personal', 'mes_pagado', 'ciclo_escolar']]
        ordering = ['-mes_pagado']

    @classmethod
    def obtener_anotaciones_sql(cls) -> dict:
        from django.db.models import F, Value, DecimalField
        from django.db.models.functions import Greatest
        return {
            'total_pagar': Greatest(
                F('personal__salario_base_asignado') + F('bonificaciones') - F('descuentos'),
                Value(Decimal('0.00')),
                output_field=DecimalField(max_digits=10, decimal_places=2),
            ),
        }

    @property
    def total_pagar(self) -> Decimal:
        sueldo = Decimal(str(self.personal.salario_base_asignado)) if self.personal_id else Decimal('0.00')
        bonos = Decimal(str(self.bonificaciones or 0))
        desc = Decimal(str(self.descuentos or 0))
        return round(max(sueldo + bonos - desc, Decimal('0.00')), 2)

    @total_pagar.setter
    def total_pagar(self, valor) -> None:
        # propiedad derivada calculada dinamicamente
        pass

    def __str__(self):
        return f"Planilla {self.get_mes_pagado_display()} - {self.personal.persona.nombre_completo} (Q{self.total_pagar})"
