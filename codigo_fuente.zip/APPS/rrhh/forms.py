"""
APPS/rrhh/forms.py

Formularios para la contratación y gestión de Personal laboral del Instituto El Progreso.
Incluye:
  - PersonalForm: Captura de datos laborales y papelería con validaciones para Guatemala (NIT SAT, teléfono de 8 dígitos).
  - AsistenciaPersonalForm: Registro de asistencia de personal.
  - PlanillaGenerarMasivaForm: Generación masiva de planilla de sueldos mensual.
  - PlanillaUpdateForm: Modificación de bonos, retenciones y estado de pago de planilla de sueldos.
"""
from decimal import Decimal
from django import forms
from django.utils import timezone
from APPS.core.forms import TailwindFormMixin
from APPS.core.validadores import (
    limpiar_nit_guatemala,
    limpiar_telefono_guatemala,
    limpiar_texto_longitud,
)
from APPS.rrhh.models import (
    Personal, Puesto, AsistenciaPersonal, Planilla,
    EstadoLaboralChoices, EstadoAsistenciaChoices, MesChoices
)
from APPS.academico.models import CicloEscolar


class PersonalForm(TailwindFormMixin, forms.ModelForm):
    """Formulario para capturar y modificar los datos laborales, custodia de contrato físico y papelería del Empleado."""

    _CAMPOS_PROPIEDADES = (
        'contacto_emergencia_nombre',
        'contacto_emergencia_telefono',
        'doc_dpi_personal',
        'doc_nit_sat',
        'doc_titulo_academico',
        'doc_colegiado_activo',
        'doc_antecedentes_penales',
        'doc_antecedentes_policiales',
        'doc_contrato_fisico',
        'doc_tarjeta_salud',
    )

    contacto_emergencia_nombre = forms.CharField(
        min_length=3,
        max_length=150,
        required=False,
        label='Nombre de Contacto de Emergencia',
        widget=forms.TextInput(attrs={
            'minlength': '3',
            'maxlength': '150',
            'placeholder': 'Nombre completo del familiar o contacto de emergencia',
        }),
    )
    contacto_emergencia_telefono = forms.CharField(
        min_length=8,
        max_length=8,
        required=False,
        label='Teléfono de Contacto de Emergencia (8 dígitos)',
        widget=forms.TextInput(attrs={
            'minlength': '8',
            'maxlength': '8',
            'pattern': r'\d{8}',
            'inputmode': 'numeric',
            'oninput': "this.value = this.value.replace(/[^0-9]/g, '').slice(0, 8)",
            'placeholder': 'Ej. 55551234',
            'title': 'Ingrese un número telefónico de Guatemala de exactamente 8 dígitos numéricos.',
        }),
    )
    doc_dpi_personal = forms.BooleanField(
        required=False,
        label='1. Fotocopia de DPI / CUI (RENAP)',
    )
    doc_nit_sat = forms.BooleanField(
        required=False,
        label='2. Constancia de NIT (RTU SAT)',
    )
    doc_titulo_academico = forms.BooleanField(
        required=False,
        label='3. Fotocopia de Título Académico / Cédula Docente',
    )
    doc_colegiado_activo = forms.BooleanField(
        required=False,
        label='4. Constancia Colegiado Activo / Acreditación MINEDUC',
    )
    doc_antecedentes_penales = forms.BooleanField(
        required=False,
        label='5. Antecedentes Penales (Vigentes)',
    )
    doc_antecedentes_policiales = forms.BooleanField(
        required=False,
        label='6. Antecedentes Policiales (Vigentes)',
    )
    doc_contrato_fisico = forms.BooleanField(
        required=False,
        label='7. Contrato Físico Firmado',
    )
    doc_tarjeta_salud = forms.BooleanField(
        required=False,
        label='8. Tarjeta de Salud / Sanidad',
    )

    class Meta:
        model = Personal
        fields = [
            'puesto',
            'nit',
            'fecha_contratacion',
            'estado_laboral',
            'salario_base_asignado',
            'numero_contrato_fisico',
            'ubicacion_expediente_fisico',
        ]
        labels = {
            'puesto': 'Puesto o Cargo Asignado',
            'nit': 'NIT (Número de Identificación Tributaria - SAT)',
            'fecha_contratacion': 'Fecha de Contratación',
            'estado_laboral': 'Estado Laboral',
            'salario_base_asignado': 'Salario Base Mensual (Q)',
            'numero_contrato_fisico': 'No. Correlativo de Contrato Físico',
            'ubicacion_expediente_fisico': 'Ubicación Físico (Archivador/Carpeta)',
        }
        widgets = {
            'nit': forms.TextInput(attrs={
                'minlength': '2',
                'maxlength': '15',
                'pattern': r'([0-9]{1,12}-?[0-9Kk]|CF|C/F|cf|c/f)',
                'placeholder': 'Ej. 1234567-8 o CF',
                'title': 'Ingrese un NIT válido de la SAT (ej. 1234567-8, 1234567K o CF).',
            }),
            'fecha_contratacion': forms.DateInput(attrs={'type': 'date'}),
            'salario_base_asignado': forms.NumberInput(attrs={
                'placeholder': '0.00',
                'step': '0.01',
                'min': '0.01',
                'max': '99999999.99',
            }),
            'numero_contrato_fisico': forms.TextInput(attrs={
                'maxlength': '50',
                'placeholder': 'Ej. CONT-2026-001',
            }),
            'ubicacion_expediente_fisico': forms.TextInput(attrs={
                'maxlength': '100',
                'placeholder': 'Ej. Archivador B-1, Carpeta 15 (Secretaría)',
            }),
        }

    def __init__(self, *args, **kwargs):
        instance = kwargs.get('instance')
        if instance is not None and getattr(instance, 'pk', None):
            initial = dict(kwargs.get('initial') or {})
            for campo in self._CAMPOS_PROPIEDADES:
                if campo not in initial:
                    initial[campo] = getattr(instance, campo)
            kwargs['initial'] = initial
        super().__init__(*args, **kwargs)

    def clean_salario_base_asignado(self):
        salario = self.cleaned_data.get('salario_base_asignado')
        if salario is not None and salario <= Decimal('0.00'):
            raise forms.ValidationError("El salario base asignado en Quetzales (Q) debe ser mayor a Q0.00.")
        return salario

    def clean_nit(self):
        nit = self.cleaned_data.get('nit')
        if nit:
            return limpiar_nit_guatemala(nit)
        return ''

    def clean_contacto_emergencia_nombre(self):
        val = self.cleaned_data.get('contacto_emergencia_nombre')
        if val:
            return limpiar_texto_longitud(
                val,
                nombre_campo='El nombre del contacto de emergencia',
                min_length=3,
                max_length=150,
                evitar_solo_numeros=True,
            )
        return ''

    def clean_contacto_emergencia_telefono(self):
        tel = self.cleaned_data.get('contacto_emergencia_telefono')
        if tel:
            return limpiar_telefono_guatemala(tel)
        return ''

    def clean_numero_contrato_fisico(self):
        val = self.cleaned_data.get('numero_contrato_fisico')
        if val:
            return limpiar_texto_longitud(val, 'El número de contrato físico', min_length=2, max_length=50)
        return ''

    def clean_ubicacion_expediente_fisico(self):
        val = self.cleaned_data.get('ubicacion_expediente_fisico')
        if val:
            return limpiar_texto_longitud(val, 'La ubicación del expediente físico', min_length=2, max_length=100)
        return ''

    def save(self, commit=True):
        personal = super().save(commit=False)
        for campo in self._CAMPOS_PROPIEDADES:
            if campo in self.cleaned_data:
                setattr(personal, campo, self.cleaned_data[campo])
        if commit:
            personal.save()
        return personal


class AsistenciaPersonalForm(TailwindFormMixin, forms.ModelForm):
    """Formulario para registro diario o justificación de asistencia de un colaborador."""

    class Meta:
        model = AsistenciaPersonal
        fields = [
            'personal',
            'fecha',
            'hora_entrada',
            'hora_salida',
            'estado_asistencia',
            'observaciones',
        ]
        labels = {
            'personal': 'Colaborador / Empleado',
            'fecha': 'Fecha de Registro',
            'hora_entrada': 'Hora de Entrada (Opcional)',
            'hora_salida': 'Hora de Salida (Opcional)',
            'estado_asistencia': 'Estado de Asistencia',
            'observaciones': 'Observaciones / Justificación de Ausencia o Permiso',
        }
        widgets = {
            'fecha': forms.DateInput(attrs={'type': 'date'}),
            'hora_entrada': forms.TimeInput(attrs={'type': 'time'}),
            'hora_salida': forms.TimeInput(attrs={'type': 'time'}),
            'observaciones': forms.Textarea(attrs={
                'rows': 2,
                'maxlength': '300',
                'placeholder': 'Detalles de tardanza, permiso especial, constancia médica (máx. 300 caracteres)...',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['personal'].queryset = Personal.objects.filter(
            esta_eliminado=False,
            estado_laboral=EstadoLaboralChoices.ACTIVO
        ).select_related('persona', 'puesto').order_by('persona__apellidos')
        if not self.initial.get('fecha'):
            self.initial['fecha'] = timezone.now().date()

    def clean_observaciones(self):
        obs = self.cleaned_data.get('observaciones')
        if obs:
            return limpiar_texto_longitud(obs, 'Las observaciones de asistencia', min_length=2, max_length=300)
        return ''

    def clean(self):
        cleaned_data = super().clean()
        hora_entrada = cleaned_data.get('hora_entrada')
        hora_salida = cleaned_data.get('hora_salida')
        if hora_entrada and hora_salida and hora_salida <= hora_entrada:
            self.add_error('hora_salida', 'La hora de salida debe ser posterior a la hora de entrada.')
        return cleaned_data


class PlanillaGenerarMasivaForm(TailwindFormMixin, forms.Form):
    """Formulario para la emisión y cálculo masivo de la planilla de sueldos mensual para todo el personal activo."""

    ciclo_escolar = forms.ModelChoiceField(
        queryset=CicloEscolar.objects.filter(esta_eliminado=False).order_by('-anio'),
        label='Ciclo Escolar',
        required=True
    )
    mes_pagado = forms.ChoiceField(
        choices=MesChoices.choices,
        label='Mes a Liquidar',
        required=True
    )
    bonificacion_ley = forms.DecimalField(
        max_digits=8,
        decimal_places=2,
        min_value=Decimal('0.00'),
        max_value=Decimal('999999.99'),
        initial=Decimal('250.00'),
        label='Bonificación Incentivo de Ley (Q)',
        help_text='Monto de bonificación según Decreto 37-2001 (Estándar Q250.00).',
        widget=forms.NumberInput(attrs={
            'step': '0.01',
            'min': '0',
            'max': '999999.99',
        }),
    )
    descontar_igss = forms.BooleanField(
        required=False,
        initial=False,
        label='¿Calcular y descontar cuota laboral IGSS (4.83%)?',
        help_text='Aplica retención del 4.83% sobre el salario base de cada trabajador.'
    )
    fecha_pago = forms.DateField(
        label='Fecha de Pago Estimada',
        initial=timezone.now().date,
        widget=forms.DateInput(attrs={'type': 'date'})
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        ciclo_activo = CicloEscolar.objects.filter(estado_activo=True, esta_eliminado=False).first()
        if ciclo_activo:
            self.fields['ciclo_escolar'].initial = ciclo_activo
        self.fields['mes_pagado'].initial = timezone.now().month


class PlanillaUpdateForm(TailwindFormMixin, forms.ModelForm):
    """Formulario para ajustar bonificaciones, retenciones y marcar pagada una boleta de pago de planilla."""

    class Meta:
        model = Planilla
        fields = [
            'bonificaciones',
            'descuentos',
            'fecha_pago',
            'pagado',
        ]
        labels = {
            'bonificaciones': 'Bonificaciones / Horas Extras (Q)',
            'descuentos': 'Descuentos / Retenciones Judiciales / Anticipos (Q)',
            'fecha_pago': 'Fecha de Pago',
            'pagado': '¿Planilla Pagada / Liquidada?',
        }
        widgets = {
            'bonificaciones': forms.NumberInput(attrs={
                'step': '0.01',
                'min': '0',
                'max': '99999999.99',
            }),
            'descuentos': forms.NumberInput(attrs={
                'step': '0.01',
                'min': '0',
                'max': '99999999.99',
            }),
            'fecha_pago': forms.DateInput(attrs={'type': 'date'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        bonificaciones = cleaned_data.get('bonificaciones') or Decimal('0.00')
        descuentos = cleaned_data.get('descuentos') or Decimal('0.00')

        if bonificaciones < 0:
            self.add_error('bonificaciones', 'El monto de bonificación no puede ser negativo.')
        if descuentos < 0:
            self.add_error('descuentos', 'El monto de descuento no puede ser negativo.')

        return cleaned_data
