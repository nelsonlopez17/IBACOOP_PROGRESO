"""
APPS/rrhh/tests.py

Pruebas unitarias automatizadas para el Módulo de Recursos Humanos:
  - Personal y puestos
  - Asistencia diaria
  - Planilla y nómina mensual (Cálculo masivo y Boletas PDF)
"""
from decimal import Decimal
from django.test import TestCase
from django.urls import reverse
from django.contrib.auth import get_user_model
from django.utils import timezone

from APPS.core.models import Persona
from APPS.usuarios.models import RolChoices
from APPS.academico.models import CicloEscolar
from APPS.rrhh.models import (
    Personal, Puesto, AsistenciaPersonal, Planilla,
    EstadoLaboralChoices, EstadoAsistenciaChoices, MesChoices
)

Usuario = get_user_model()


class RecursosHumanosTestCase(TestCase):

    def setUp(self):
        self.admin_user = Usuario.objects.create_user(
            username='2580123450101',
            email='admin.rrhh@ibacoop.edu.gt',
            password='TestPassword123!',
            rol=RolChoices.ADMINISTRADOR,
            is_staff=True,
            is_superuser=True
        )

        self.ciclo = CicloEscolar.objects.create(
            anio=2026,
            estado_activo=True
        )

        self.puesto = Puesto.objects.create(
            nombre_puesto='Docente de Matemáticas'
        )

        self.persona1 = Persona.objects.create(
            cui='1000000000001',
            nombres='Lucía',
            apellidos='Méndez',
            fecha_nacimiento='1990-04-12',
            correo='lucia.mendez@ibacoop.edu.gt',
            telefono_principal='55551111'
        )
        self.emp1 = Personal.objects.create(
            persona=self.persona1,
            puesto=self.puesto,
            fecha_contratacion='2022-01-10',
            salario_base_asignado=Decimal('3500.00'),
            estado_laboral=EstadoLaboralChoices.ACTIVO
        )

        self.persona2 = Persona.objects.create(
            cui='1000000000002',
            nombres='Mario',
            apellidos='López',
            fecha_nacimiento='1988-08-20',
            correo='mario.lopez@ibacoop.edu.gt',
            telefono_principal='55552222'
        )
        self.emp2 = Personal.objects.create(
            persona=self.persona2,
            puesto=self.puesto,
            fecha_contratacion='2021-02-01',
            salario_base_asignado=Decimal('4000.00'),
            estado_laboral=EstadoLaboralChoices.ACTIVO
        )

    def test_registro_asistencia_personal(self):
        """Verifica la creación y actualización de asistencia diaria de un colaborador."""
        self.client.force_login(self.admin_user)
        hoy = timezone.now().date()

        response = self.client.post(reverse('rrhh:asistencia_create'), {
            'personal': self.emp1.pk,
            'fecha': str(hoy),
            'hora_entrada': '07:30',
            'hora_salida': '13:00',
            'estado_asistencia': EstadoAsistenciaChoices.PRESENTE,
            'observaciones': 'Ingreso puntual.'
        })
        self.assertEqual(response.status_code, 302)

        asis = AsistenciaPersonal.objects.get(personal=self.emp1, fecha=hoy)
        self.assertEqual(asis.estado_asistencia, EstadoAsistenciaChoices.PRESENTE)

        res_list = self.client.get(reverse('rrhh:asistencia_list'))
        self.assertEqual(res_list.status_code, 200)

    def test_generacion_masiva_planilla(self):
        """Verifica el cálculo y emisión masiva de planilla para empleados activos con bonificación e IGSS."""
        self.client.force_login(self.admin_user)

        response = self.client.post(reverse('rrhh:planilla_generar'), {
            'ciclo_escolar': self.ciclo.pk,
            'mes_pagado': MesChoices.MARZO,
            'bonificacion_ley': '250.00',
            'descontar_igss': True,
            'fecha_pago': '2026-03-30'
        })
        self.assertEqual(response.status_code, 302)

        pl1 = Planilla.objects.get(personal=self.emp1, mes_pagado=MesChoices.MARZO, ciclo_escolar=self.ciclo)
        self.assertEqual(pl1.bonificaciones, Decimal('250.00'))
        self.assertEqual(pl1.descuentos, Decimal('169.05'))
        self.assertEqual(pl1.total_pagar, Decimal('3580.95'))

        pl2 = Planilla.objects.get(personal=self.emp2, mes_pagado=MesChoices.MARZO, ciclo_escolar=self.ciclo)
        self.assertEqual(pl2.total_pagar, Decimal('4056.80'))

    def test_ajuste_individual_planilla_y_descarga_pdf(self):
        """Verifica modificación individual de nómina y generación del comprobante oficial en PDF."""
        self.client.force_login(self.admin_user)

        # calculo de retenciones de ley y sueldo liquido en planilla
        pl = Planilla.objects.create(
            personal=self.emp1,
            ciclo_escolar=self.ciclo,
            mes_pagado=MesChoices.ABRIL,
            bonificaciones=Decimal('250.00'),
            descuentos=Decimal('100.00'),
            total_pagar=Decimal('3650.00'),
            pagado=False
        )

        response = self.client.post(reverse('rrhh:planilla_update', kwargs={'pk': pl.pk}), {
            'bonificaciones': '500.00',
            'descuentos': '100.00',
            'fecha_pago': '2026-04-30',
            'pagado': True
        })
        self.assertEqual(response.status_code, 302)

        pl.refresh_from_db()
        self.assertTrue(pl.pagado)
        self.assertEqual(pl.total_pagar, Decimal('3900.00'))  # 3500 + 500 - 100

        res_pdf = self.client.get(reverse('rrhh:planilla_pdf', kwargs={'pk': pl.pk}))
        self.assertEqual(res_pdf.status_code, 200)
        self.assertEqual(res_pdf['Content-Type'], 'application/pdf')
