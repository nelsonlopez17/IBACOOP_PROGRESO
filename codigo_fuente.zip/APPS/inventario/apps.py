from django.apps import AppConfig


class InventarioConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'APPS.inventario'
    verbose_name = 'Control de Inventario'
