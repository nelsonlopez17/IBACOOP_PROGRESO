"""
APPS/disciplina/forms.py

Formularios para el registro de incidentes disciplinarios y emisión de citaciones
a padres de familia o encargados con soporte de Tailwind CSS y validaciones operativas
conforme al Acuerdo Ministerial 01-2011 del MINEDUC (Guatemala).
"""
from datetime import date
from django import forms
from django.utils import timezone
from APPS.core.forms import TailwindFormMixin
from APPS.core.validadores import limpiar_texto_longitud
from APPS.disciplina.models import IncidenteDisciplinario, CitacionPadre
from APPS.estudiantes.models import Estudiante


class IncidenteDisciplinarioForm(TailwindFormMixin, forms.ModelForm):
    """Formulario para reportar o actualizar una falta disciplinaria de un estudiante."""

    class Meta:
        model = IncidenteDisciplinario
        fields = [
            'estudiante',
            'ciclo_escolar',
            'fecha',
            'hora',
            'lugar',
            'tipo_falta',
            'categoria',
            'descripcion_hechos',
            'descargo_estudiante',
            'medida_formativa',
            'requiere_citacion',
            'esta_resuelto',
        ]
        widgets = {
            'fecha': forms.DateInput(attrs={'type': 'date'}),
            'hora': forms.TimeInput(attrs={'type': 'time'}),
            'lugar': forms.TextInput(attrs={
                'minlength': '3',
                'maxlength': '150',
                'placeholder': 'Ej. Aula 102, Patio Central, Laboratorio de Computación',
            }),
            'descripcion_hechos': forms.Textarea(attrs={
                'rows': 3,
                'minlength': '10',
                'maxlength': '1000',
                'placeholder': 'Relate con claridad y objetividad los hechos observados (10 a 1,000 caracteres)...',
            }),
            'descargo_estudiante': forms.Textarea(attrs={
                'rows': 2,
                'maxlength': '1000',
                'placeholder': 'Declaración u observaciones expresadas por el estudiante durante la audiencia...',
            }),
            'medida_formativa': forms.Textarea(attrs={
                'rows': 2,
                'maxlength': '1000',
                'placeholder': 'Acción correctiva pedagógica acordada (ej. amonestación escrita, labor formativa)...',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['estudiante'].queryset = Estudiante.objects.filter(
            persona__esta_eliminado=False,
            estado_estudiante='ACTIVO'
        ).select_related('persona').order_by('persona__apellidos', 'persona__nombres')

    def clean_fecha(self):
        fecha = self.cleaned_data.get('fecha')
        if fecha and fecha > date.today():
            raise forms.ValidationError('La fecha del incidente disciplinario no puede ser una fecha futura.')
        return fecha

    def clean_lugar(self):
        lugar = self.cleaned_data.get('lugar')
        if lugar:
            return limpiar_texto_longitud(lugar, 'El lugar de los hechos', min_length=3, max_length=150, obligatorio=True)
        return lugar

    def clean_descripcion_hechos(self):
        desc = self.cleaned_data.get('descripcion_hechos')
        if desc:
            return limpiar_texto_longitud(
                desc,
                nombre_campo='La descripción de los hechos',
                min_length=10,
                max_length=1000,
                obligatorio=True,
            )
        return desc

    def clean_descargo_estudiante(self):
        val = self.cleaned_data.get('descargo_estudiante')
        if val:
            return limpiar_texto_longitud(val, 'El descargo del estudiante', min_length=3, max_length=1000)
        return val

    def clean_medida_formativa(self):
        val = self.cleaned_data.get('medida_formativa')
        if val:
            return limpiar_texto_longitud(val, 'La medida formativa', min_length=3, max_length=1000)
        return val


class CitacionPadreForm(TailwindFormMixin, forms.ModelForm):
    """Formulario para emitir y registrar el resultado de una citación a padres de familia o encargados."""

    class Meta:
        model = CitacionPadre
        fields = [
            'fecha_hora_citacion',
            'motivo_citacion',
            'lugar',
            'atendido_por',
            'estado',
            'acuerdos_alcanzados',
            'observaciones_seguimiento',
            'notificacion_enviada',
        ]
        widgets = {
            'fecha_hora_citacion': forms.DateTimeInput(attrs={'type': 'datetime-local'}),
            'motivo_citacion': forms.TextInput(attrs={
                'minlength': '5',
                'maxlength': '255',
                'placeholder': 'Motivo formal para comparecencia del padre de familia o encargado',
            }),
            'lugar': forms.TextInput(attrs={
                'minlength': '3',
                'maxlength': '150',
                'placeholder': 'Ej. Dirección / Coordinación Pedagógica',
            }),
            'acuerdos_alcanzados': forms.Textarea(attrs={
                'rows': 3,
                'maxlength': '1000',
                'placeholder': 'Acuerdos formales de apoyo mutuo y compromisos de convivencia firmados...',
            }),
            'observaciones_seguimiento': forms.Textarea(attrs={
                'rows': 2,
                'maxlength': '1000',
                'placeholder': 'Notas internas para dar seguimiento en las próximas semanas...',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from django.contrib.auth import get_user_model
        UsuarioModel = get_user_model()
        self.fields['atendido_por'].queryset = UsuarioModel.objects.filter(is_active=True).order_by('first_name', 'last_name')

    def clean_motivo_citacion(self):
        motivo = self.cleaned_data.get('motivo_citacion')
        if motivo:
            return limpiar_texto_longitud(motivo, 'El motivo de la citación', min_length=5, max_length=255, obligatorio=True)
        return motivo

    def clean_lugar(self):
        lugar = self.cleaned_data.get('lugar')
        if lugar:
            return limpiar_texto_longitud(lugar, 'El lugar de reunión', min_length=3, max_length=150, obligatorio=True)
        return lugar

    def clean_acuerdos_alcanzados(self):
        val = self.cleaned_data.get('acuerdos_alcanzados')
        if val:
            return limpiar_texto_longitud(val, 'Los acuerdos alcanzados', min_length=3, max_length=1000)
        return val

    def clean_observaciones_seguimiento(self):
        val = self.cleaned_data.get('observaciones_seguimiento')
        if val:
            return limpiar_texto_longitud(val, 'Las observaciones de seguimiento', min_length=3, max_length=1000)
        return val


# alias para compatibilidad con llamadas previas
IncidenteConductualForm = IncidenteDisciplinarioForm
